import net from 'node:net';
import tls from 'node:tls';
import {execFile} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {lookup as dnsLookup} from 'node:dns/promises';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {networkInterfaces} from 'node:os';
import {scanSpec,localAddress,singleTarget} from '../server/lib/wolfguard/scan-spec.mjs';
import {evaluateSecurity} from './security-rules.mjs';
import {collectPosixPassive,collectPosixSecurity} from './posix.mjs';

const SERVICES={21:'FTP',22:'SSH',23:'Telnet',25:'SMTP',53:'DNS',80:'HTTP',110:'POP3',135:'RPC',139:'NetBIOS',143:'IMAP',389:'LDAP',443:'HTTPS',445:'SMB',636:'LDAPS',993:'IMAPS',995:'POP3S',1433:'SQL Server',3306:'MySQL',3389:'RDP',5432:'PostgreSQL',5900:'VNC',5985:'WinRM',5986:'WinRM TLS',6379:'Redis',8080:'HTTP',8443:'HTTPS'};
export function fixedProcess(file,args,{input='',signal,timeout=20000,maxBytes=3*1024*1024}={}){
  return new Promise((resolve,reject)=>{const child=execFile(file,args,{windowsHide:true,encoding:'utf8',timeout,maxBuffer:maxBytes,signal,env:{...process.env,LC_ALL:'C',LANG:'C'}},(error,stdout,stderr)=>{if(error){error.stdout=stdout;error.stderr=stderr;reject(error);}else resolve(stdout);});child.stdin.on('error',()=>{});child.stdin.end(input);});
}
export async function collectPassive(signal){
  let data;
  if(process.platform!=='win32')data=await collectPosixPassive(signal,{run:fixedProcess});
  else{
    const result=await fixedProcess('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',fileURLToPath(new URL('./collect.ps1',import.meta.url))],{signal,timeout:30000});
    data=JSON.parse(result.replace(/^\uFEFF/,''));if(!Array.isArray(data.results))throw new Error('Relevé Windows illisible.');
  }
  data.localAddresses=[...new Set([...(data.localAddresses||[]),...Object.values(networkInterfaces()).flat().filter(Boolean).map(item=>item.address)])];
  try{
    const hosts=await readFile(process.platform==='win32'?join(process.env.SystemRoot||'C:\\Windows','System32','drivers','etc','hosts'):'/etc/hosts','utf8');
    for(const line of hosts.split(/\r?\n/)){
      const [address,...names]=line.split('#',1)[0].trim().split(/\s+/);
      for(const hostname of names)data.results.push({address,hostname,transport:'DNS',status:'observed',source:'agent-hosts',detail:'Association présente dans le fichier hosts local.'});
    }
  }catch{data.warnings.push('Fichier hosts local indisponible.');}
  return data;
}
export function passiveTargetRows(snapshot,addresses,target){
  const normalize=value=>{try{return localAddress(String(value||'').split('%')[0]);}catch{return '';}};
  const known=addresses.find(address=>snapshot.results.some(row=>normalize(row.address)===address||normalize(row.remoteAddress)===address));
  const selected=known||addresses[0];if(!selected)return [];
  const local=new Set((snapshot.localAddresses||[]).map(normalize)),isLocal=local.has(selected)||selected==='::1'||/^127\./.test(selected);
  const rows=[],seen=new Set();
  const add=row=>{const key=JSON.stringify([row.address,row.port,row.transport,row.hostname,row.localAddress,row.localPort,row.remoteAddress,row.remotePort,row.pid,row.interfaceName]);if(!seen.has(key)){seen.add(key);rows.push(row);}};
  for(const row of snapshot.results){
    const address=normalize(row.address),remote=normalize(row.remoteAddress),transport=String(row.transport||'').toUpperCase();
    if(address===selected&&row.status==='observed'&&['ARP','NDP','DNS'].includes(transport)){
      add({...row,address:selected,port:null,transport,hostname:row.hostname||(!target.includes(':')&&!/^[\d.]+$/.test(target)?target:''),source:row.source||'agent-local-cache'});
    }else if(['TCP','UDP'].includes(transport)&&['connection','listening','bound'].includes(row.status)){
      if(remote===selected&&row.status==='connection')add({...row,address:selected,port:row.remotePort,localAddress:address,localPort:row.port,remoteAddress:remote,remotePort:row.remotePort,direction:'remote',source:row.source||'agent-connection-table'});
      else if(address===selected||isLocal&&['0.0.0.0','::'].includes(String(row.address)))add({...row,address:selected,localAddress:row.address,localPort:row.port,remoteAddress:row.remoteAddress||'',direction:'local',source:row.source||'agent-local-socket'});
    }
  }
  return rows;
}
export async function collectSecurity(signal){
  if(process.platform!=='win32')return collectPosixSecurity(signal,{run:fixedProcess});
  const output=await fixedProcess('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',fileURLToPath(new URL('./security.ps1',import.meta.url))],{signal,timeout:90000});
  return evaluateSecurity(JSON.parse(output.replace(/^\uFEFF/,'')));
}
// Cache-only resolution never calls DNS, ping, getent or another network resolver.
export async function cachedTargetAddresses(name,rows=[],{platform=process.platform,read=path=>readFile(path,'utf8'),run=fixedProcess,signal}={}){
  const found=rows.filter(row=>row.hostname?.toLowerCase().replace(/\.$/,'')===name).map(row=>row.address);
  try{
    const hosts=await read(platform==='win32'?join(process.env.SystemRoot||'C:\\Windows','System32','drivers','etc','hosts'):'/etc/hosts');
    for(const line of hosts.split(/\r?\n/)){const [address,...names]=line.split('#',1)[0].trim().split(/\s+/);if(names.some(value=>value.toLowerCase().replace(/\.$/,'')===name))found.push(address);}
  }catch{}
  if(platform==='win32'){
    const script="$name=[Console]::In.ReadToEnd().Trim(); @((Get-DnsClientCache -ErrorAction SilentlyContinue | Where-Object { $_.Entry.TrimEnd('.') -ieq $name -and $_.Type -in 1,28 }) | ForEach-Object { $_.Data }) | ConvertTo-Json -Compress";
    try{const value=JSON.parse((await run('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-Command',script],{input:name,signal,timeout:8000})).replace(/^\uFEFF/,''));found.push(...(Array.isArray(value)?value:typeof value==='string'?[value]:[]));}catch(error){if(signal?.aborted)throw error;}
  }
  return [...new Set(found.map(value=>{try{return localAddress(value);}catch{return '';}}).filter(Boolean))];
}
export async function activeTargetAddress(target,{lookup=dnsLookup,signal}={}){
  signal?.throwIfAborted();
  const name=singleTarget(target);if(name.includes(':')||/^[\d.]+$/.test(name))return name;
  const stop=new AbortController();let timeout;
  const abort=()=>stop.abort(signal?.reason||new Error('Scan arrêté.'));
  signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();
  const cancelled=new Promise((_,reject)=>{stop.signal.addEventListener('abort',()=>reject(stop.signal.reason),{once:true});if(stop.signal.aborted)reject(stop.signal.reason);timeout=setTimeout(()=>stop.abort(new Error('Résolution DNS trop longue.')),5000);});
  try{
    const records=await Promise.race([lookup(name,{all:true,verbatim:true}),cancelled]);
    if(!records.length||records.length>64)throw new Error('Aucune adresse utilisable pour ce FQDN.');
    // Validate every answer, then pin one numeric address for all probes (no second lookup).
    return records.map(record=>localAddress(record.address))[0];
  }finally{clearTimeout(timeout);signal?.removeEventListener('abort',abort);}
}
export function serviceFingerprint(content){
  const ssh=/\bOpenSSH[_ /-](\d+(?:\.\d+)+(?:p\d+)?)/i.exec(content);if(ssh)return {service:'SSH',product:'OpenSSH',version:ssh[1]};
  const server=/^server:\s*([^\r\n]+)/im.exec(content)?.[1]||content.split(/\r?\n/,1)[0];
  const match=/\b(nginx|Apache|OpenSSL|Tomcat|PostgreSQL|Redis|Microsoft-IIS)[/ ](\d+(?:\.\d+)+(?:p\d+)?)/i.exec(server);
  return {service:/^HTTP\//.test(content)?'HTTP':'',product:match?.[1]||server.slice(0,400),version:match?.[2]||''};
}
function bannerEvidence(content){
  if(/^HTTP\//.test(content))return [content.split(/\r?\n/,1)[0],/^server:[^\r\n]*/im.exec(content)?.[0]].filter(Boolean).join('\n').slice(0,600);
  return content.split(/\r?\n/,1)[0].slice(0,400);
}
function probe(address,port,timeout,signal,identify,hostname=address){
  localAddress(address);
  return new Promise(resolve=>{
    const started=performance.now(),socket=new net.Socket();let done=false,timer;
    const row={address,port,transport:'TCP',source:'agent-tcp',...(hostname!==address?{hostname}:{})};
    function finish(status,detail,extra={}){if(done)return;done=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);socket.destroy();resolve({...row,status,latencyMs:Math.round(performance.now()-started),detail,...extra});}
    const abort=()=>finish('error','Test arrêté.');if(signal?.aborted){abort();return;}signal?.addEventListener('abort',abort,{once:true});
    timer=setTimeout(()=>finish('no-response','Aucune réponse avant le délai.'),timeout);
    socket.once('error',error=>finish(error.code==='ECONNREFUSED'?'closed':['EHOSTUNREACH','ENETUNREACH'].includes(error.code)?'unreachable':'error','TCP : '+String(error.code||'erreur')));
    socket.connect({host:address,port},async()=>{
      if(done)return;clearTimeout(timer);timer=setTimeout(()=>finish('open','Connexion TCP établie ; identification non concluante.'),1500);
      if(!identify){finish('open','Connexion TCP établie. Le nom du service est une association de port, non une identification.',{service:SERVICES[port]?SERVICES[port]+' (port usuel)':''});return;}
      let stream=socket,content='';
      if([443,465,636,853,993,995,5986,8443].includes(port)){
        stream=tls.connect({socket,host:hostname,...(hostname!==address?{servername:hostname}:{}),rejectUnauthorized:true},()=>{const cert=stream.getPeerCertificate();if([443,8443].includes(port)){stream.write('HEAD / HTTP/1.0\r\nHost: '+(hostname.includes(':')?'['+hostname+']':hostname)+'\r\nConnection: close\r\n\r\n');return;}finish('open','Négociation TLS validée. Certificat : '+String(cert.subject?.CN||'')+' ; expiration : '+String(cert.valid_to||''),{service:stream.getProtocol()||'TLS'});stream.destroy();});
        if([443,8443].includes(port)){stream.on('data',chunk=>{content+=chunk.toString('utf8');if(content.length>=4096||content.includes('\r\n\r\n'))finish('open','En-têtes HTTPS reçus : '+bannerEvidence(content),serviceFingerprint(content));});stream.once('end',()=>finish('open',content?'En-têtes HTTPS reçus : '+bannerEvidence(content):'TLS établi ; aucun en-tête reçu.',content?serviceFingerprint(content):{service:'HTTPS'}));}
        stream.once('error',error=>{finish('open','Port ouvert ; validation TLS non aboutie : '+String(error.code||'erreur'));stream.destroy();});
      }else{
        stream.on('data',chunk=>{content+=chunk.toString('utf8');if(content.length>=4096||(/^HTTP\//.test(content)?content.includes('\r\n\r\n'):content.includes('\n'))){finish('open','Bannière reçue : '+bannerEvidence(content),serviceFingerprint(content));}});
        if([80,8000,8080,8081,9090].includes(port))stream.write('HEAD / HTTP/1.0\r\nHost: '+(hostname.includes(':')?'['+hostname+']':hostname)+'\r\nConnection: close\r\n\r\n');
        stream.once('end',()=>finish('open',content?'Bannière reçue : '+bannerEvidence(content):'Port ouvert ; aucune bannière reçue.',content?serviceFingerprint(content):{}));
      }
    });
  });
}
async function ping(address,timeout,signal){
  localAddress(address);const started=performance.now();
  const windows=process.platform==='win32',mac=process.platform==='darwin';
  const file=windows?'ping.exe':mac&&address.includes(':')?'/sbin/ping6':'ping';
  const args=windows?['-n','1','-w',String(timeout),address]:mac?['-n','-c','1','-W',String(timeout),address]:['-n',...(address.includes(':')?['-6']:[]),'-c','1','-W',String(Math.max(1,Math.ceil(timeout/1000))),address];
  try{const output=await fixedProcess(file,args,{signal,timeout:timeout+1500,maxBytes:16000});const replied=windows?/(?:Reply from|R.ponse de)[^\r\n]*(?:TTL=|temps[=<]|time[=<])/i.test(output):/\bbytes from\b/i.test(output);return {address,port:null,transport:'ICMP',status:replied?'reachable':'no-response',latencyMs:Math.round(performance.now()-started),detail:replied?'Réponse ICMP reçue.':'Aucune réponse ICMP identifiable.',source:'agent-icmp'};}catch{return {address,port:null,transport:'ICMP',status:'no-response',detail:'Aucune réponse ICMP ; cela ne prouve pas l’absence de la machine.',source:'agent-icmp'};}
}
export function automaticMap(interfaces=networkInterfaces()){
  const interfacesFound=Object.entries(interfaces).flatMap(([name,entries])=>(entries||[]).filter(entry=>!entry.internal&&entry.family==='IPv4'&&/^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.)/.test(entry.address)).map(entry=>({name,...entry}))).sort((a,b)=>Number(/virtual|vmware|vbox|hyper-v|vpn|docker|vethernet/i.test(a.name))-Number(/virtual|vmware|vbox|hyper-v|vpn|docker|vethernet/i.test(b.name)));
  const chosen=interfacesFound[0];if(!chosen)throw new Error('Aucune interface IPv4 privée disponible pour la cartographie automatique.');
  const prefix=Math.max(24,Math.min(32,Number(chosen.cidr?.split('/')[1])||24)),mask=(0xffffffff<<(32-prefix))>>>0,n=chosen.address.split('.').reduce((value,part)=>(value*256+Number(part))>>>0,0),network=(n&mask)>>>0,target=[24,16,8,0].map(shift=>(network>>>shift)&255).join('.')+'/'+prefix;
  return {target,origin:{address:chosen.address,interfaceName:chosen.name,cidr:chosen.cidr||target},interfaces:interfacesFound.map(entry=>({name:entry.name,address:entry.address,cidr:entry.cidr}))};
}
export async function runNetworkScan(raw,{signal,onProgress=()=>{},passiveCollector=collectPassive,securityCollector=collectSecurity,lookup=dnsLookup,cacheOptions={}}={}){
  const mapping=raw.workspace==='map'&&(!raw.target||raw.target==='auto')?automaticMap():null;
  const spec=scanSpec(mapping?{...raw,target:mapping.target}:raw),startedAt=new Date().toISOString(),rows=[],warnings=[];let completed=0,total=0,identifications=0,size=0,truncated=false,software=[];
  const report=()=>({strategy:spec.strategy,platform:process.platform,...(spec.workspace?{workspace:spec.workspace}:{}),target:spec.target||'Poste de l’agent',...(mapping?{network:mapping}:{}),startedAt,finishedAt:new Date().toISOString(),completed,total,cancelled:!!signal?.aborted,results:rows,warnings,...(software.length?{software}:{})});
  function add(row){const bytes=Buffer.byteLength(JSON.stringify(row));if(rows.length>=5000||size+bytes>850000){if(!truncated){warnings.push('Résultats limités à 5 000 observations ou 850 Ko. Les compteurs peuvent dépasser les lignes détaillées.');truncated=true;}return;}size+=bytes;rows.push(row);}
  if(spec.strategy==='passive'){
    const snapshot=await (spec.passiveScope==='security'?securityCollector:passiveCollector)(signal);
    if(spec.passiveScope==='security')software=(Array.isArray(snapshot.software)?snapshot.software:[]).slice(0,200).map(item=>({name:String(item.name||'').slice(0,160),version:String(item.version||'').slice(0,100),source:String(item.source||'Inventaire local').slice(0,160),evidence:String(item.evidence||'').slice(0,400)}));
    let matches=null;
    if(spec.passiveScope!=='security'){
      const addresses=spec.target.includes(':')||/^[\d.]+$/.test(spec.target)?[spec.target]:await cachedTargetAddresses(spec.target,snapshot.results,{...cacheOptions,signal});
      matches=addresses;
    }
    for(const row of spec.passiveScope==='security'?snapshot.results:passiveTargetRows(snapshot,matches,spec.target)){if(signal?.aborted)break;add(row);}
    if(matches&&!rows.length)warnings.push(matches.length?'Aucune observation locale connue pour '+spec.target+'. Aucune sonde envoyée.':'Aucune association locale connue pour ce FQDN (fichier hosts ou cache DNS Windows). Aucune requête DNS ni sonde envoyée.');
    warnings.push(...(snapshot.warnings||[]).slice(0,10));completed=total=rows.length;onProgress(report());return report();
  }
  if(spec.workspace!=='map'){
    const address=await activeTargetAddress(spec.target,{lookup,signal});spec.addresses=[address];
    if(address!==spec.target)warnings.push('Cible '+spec.target+' : une seule adresse retenue pour tous les tests, '+address+'.');
  }
  total=spec.mode==='tcp'?spec.addresses.length*spec.ports.length:spec.addresses.length;let next=0;
  async function worker(){while(!signal?.aborted){const index=next++;if(index>=total)return;let row;
    if(spec.mode==='icmp')row=await ping(spec.addresses[index],spec.timeoutMs,signal);
    else if(spec.mode==='discovery'){
      const address=spec.addresses[index];let evidence=null;
      for(const port of spec.ports){if(signal?.aborted)break;const result=await probe(address,port,spec.timeoutMs,signal,false);if(['open','closed'].includes(result.status)){evidence=result;break;}}
      row={address,port:null,transport:'HOST',source:'agent-discovery',status:evidence?'reachable':'no-response',detail:evidence?'Réponse TCP sur '+evidence.port+' : '+(evidence.status==='open'?'connexion établie.':'connexion refusée.'):'Aucune réponse aux ports de découverte ; la machine peut filtrer les sondes.'};
    }else {const address=spec.addresses[Math.floor(index/spec.ports.length)],port=spec.ports[index%spec.ports.length];row=await probe(address,port,spec.timeoutMs,signal,spec.identifyServices&&identifications++<128,spec.workspace==='map'?address:spec.target);}
    if(signal?.aborted)break;add(row);completed++;onProgress(report());
  }}
  onProgress(report());await Promise.all(Array.from({length:Math.min(spec.concurrency,total)},worker));
  if(signal?.aborted)warnings.push('Scan interrompu : le rapport ne contient que les tests terminés.');return report();
}
